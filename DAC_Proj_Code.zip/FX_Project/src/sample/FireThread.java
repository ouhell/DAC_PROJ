package sample;

import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

import java.util.concurrent.Semaphore;

public class FireThread extends Thread{

    private boolean Fire = true;
    private final Circle Green_Light;
    private final  Circle Red_Light;
    private final Semaphore F1 ,F2;

    public Semaphore getF1() {
        return F1;
    }

    public Semaphore getF2() {
        return F2;
    }

    FireThread(Circle g , Circle r){
        this.Red_Light = r;
        this.Green_Light = g;

        this.F1 = new Semaphore(1);
        this.F2 = new Semaphore(0);
    }


    @Override
    public void run() {
        Green_Light.setFill(Color.valueOf("#1fff5a"));
        Red_Light.setFill(Color.GRAY);


        while(true){

            try {
                sleep(8000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            reverse();
            if(this.Fire){
                reserve(F2);
                F1.release();

                Green_Light.setFill(Color.valueOf("#1fff5a"));
                Red_Light.setFill(Color.GRAY);

            }else{
                reserve(F1);
                F2.release();
                Green_Light.setFill(Color.GRAY);
                Red_Light.setFill(Color.valueOf("#ff1f1f"));

            }

        }
    }

    private void reserve(Semaphore f) {
        try {
            f.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
            System.out.println("Trafic light could reserve Fire");
        }
    }

    private void reverse(){
        this.Fire = !this.Fire;
    }
}
