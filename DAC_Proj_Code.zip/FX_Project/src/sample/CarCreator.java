package sample;

import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.Semaphore;

public class CarCreator extends Thread{
    private final int Vertical_Edge_Y =  480 , Vertical_notIn_Y  = 800 ,  Vertical_out_Y = -100 ,  Vertical_final_X = 380;
    private final int Horizontal_Edge_X =  240 , Horizontal_notIn_X  = -100 ,  Horizontal_out_X = 800 ,  Horizontal_final_Y = 360;
    private  final int Height , Drop_Duration = 1600;
    private final String Type;
    private final  ArrayList<Car> CarList;
    private final  Semaphore ListSemaphore, FireSemaphore , DirectionSemaphore , CreateSemaphore;

    private final AnchorPane Pane;


    CarCreator(String type , Semaphore fire , AnchorPane communicatedView , int height , Semaphore create){
        this.Type = type;
        this.CarList =  new ArrayList<Car>();
        this.ListSemaphore = new Semaphore(1);

        this.FireSemaphore = fire;
        this.DirectionSemaphore = new Semaphore(1);
        this.Pane = communicatedView;
        this.Height = height;
        this.CreateSemaphore = create;

    }

    @Override
    public void run() {
        if(!Type.equals("vertical")) sleepOff(1000);
        while (true){
            int sleep_time = 4000;
            Car newCar =  createCar();

            reserveCar(newCar);
            reserveList();
            int carNumb = CarList.size();
            CarList.add(newCar);


            // change sleep time depending on how many cars there
             if(carNumb < 3 ){
                sleep_time = 2000;
            }
            //



            dropNewCar(newCar,carNumb);
            ListSemaphore.release();
            new java.util.Timer().schedule(
                    new java.util.TimerTask() {
                        @Override
                        public void run() {
                            newCar.getCarSemaphore().release();
                            createCarThread(newCar);

                        }
                    },
                    Drop_Duration
            );
             sleepOff(sleep_time);

        }


    }

    private void createCarThread(Car newCar) {
        CarThread newCarThread = new CarThread(newCar,FireSemaphore, ListSemaphore,DirectionSemaphore, CarList ,Height ,Pane );
        newCarThread.start();
    }


    private void sleepOff(int durr){
        try {

            sleep(durr);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void dropNewCar(Car car, int size) {
        int x = 0 , y =0 ;
         ImageView carModel = car.getCarModel();
        TranslateTransition translate = new TranslateTransition();
        translate.setNode(carModel);
        translate.setDuration(Duration.millis(Drop_Duration));

        if(Type.equals("vertical")){
          x = Vertical_final_X;
          y = Vertical_notIn_Y +  (size * Height);
          translate.setByY(Vertical_Edge_Y - Vertical_notIn_Y);
        }
        else{
            x = Horizontal_notIn_X - (size * Height);
            y = Horizontal_final_Y;
            translate.setByX(Horizontal_Edge_X - Horizontal_notIn_X);
            carModel.setRotate(90);
        }
        carModel.setX(x);
        carModel.setY(y);



        try {
            CreateSemaphore.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Platform.runLater(()->{
            Pane.getChildren().add(carModel);

             CreateSemaphore.release();
        });






        translate.play();
    }

    private void reserveCar(Car car) {
        try {
            car.getCarSemaphore().acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public Car createCar(){
        ImageView carModel = createModel();
        Car newCar = new Car(Type, carModel );
        return newCar ;
    }



    private ImageView createModel() {
        Random random = new Random();
        int checkout = random.nextInt(3)+1;
        String image ="";
        switch (checkout){
            case 1 :
                image = "the_blue_car.png";
                break;
            case 2 :
                image = "the_green_car.png";
                break;

            case 3 :
                image = "the_red_car.png";
                break;
            default:
                image = "Error in picking car model!!!!";
                System.out.println(image);
                return  null;

        }
        ImageView carModel = new ImageView();
        try{
            carModel.setImage(new Image(image));
        } catch (Exception e){
            e.printStackTrace();
            System.out.println("Wrong path to image of car model!!!!");
        }
        carModel.setFitWidth(50);
        carModel.setFitHeight(Height);

        return  carModel;

    }
    private void reserveList() {
        try {
            ListSemaphore.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
            System.out.println("The creator wasn't able to reserve  the list");
        }
    }
}
