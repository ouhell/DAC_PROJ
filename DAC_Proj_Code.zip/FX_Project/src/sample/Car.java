package sample;

import javafx.animation.TranslateTransition;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import java.util.concurrent.Semaphore;

public class Car {
    private final  String Type;
    private final  Semaphore CarSemaphore;
    private final  ImageView CarModel;



    public Semaphore getCarSemaphore() {
        return CarSemaphore;
    }

    public ImageView getCarModel() {
        return CarModel;
    }


    Car(String type , ImageView carModel ){
        this.Type = type;
        this.CarModel = carModel;
        this.CarSemaphore = new Semaphore(1);
    }

    public String getType() {
        return Type;
    }

    public void move(int duration,int distance){
        TranslateTransition translate = new TranslateTransition();
        translate.setNode(CarModel);
        translate.setDuration(Duration.millis(duration));
        if(Type.equals("vertical")){
            translate.setByY(-distance);
            }
        else{
            translate.setByX(distance);
        }
        translate.play();
    }

    public void reposition(int height,int duration){
        TranslateTransition translate = new TranslateTransition();
        translate.setNode(CarModel);
        translate.setDuration(Duration.millis(duration));
        if(Type.equals("vertical")) {
            translate.setByY(-height);
        }
        else{
            translate.setByX(height);
        }
            translate.play();
    }
    }

