package sample;


import javafx.fxml.FXML;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Circle;
import java.util.concurrent.Semaphore;


public class Controler {
  @FXML
  Circle green_light;
  @FXML
  Circle red_light;
  @FXML
  AnchorPane pane;

  final int Height = 80;

  public void startFire(){



    FireThread fireThread = new FireThread(green_light,red_light);
    Semaphore create = new Semaphore(1);
    CarCreator verticalCreator = new CarCreator("vertical",fireThread.getF1(),pane,Height,create);
    CarCreator horizontalCreator = new CarCreator("horizontal",fireThread.getF2(),pane,Height,create);
    verticalCreator.setDaemon(true);
    horizontalCreator.setDaemon(true);
    fireThread.start();
    verticalCreator.start();
    horizontalCreator.start();
  }


}
