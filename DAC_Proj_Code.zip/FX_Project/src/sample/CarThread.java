package sample;

import javafx.application.Platform;
import javafx.scene.layout.AnchorPane;

import java.util.ArrayList;
import java.util.concurrent.Semaphore;

public class CarThread extends Thread{
    private final   Car The_Car;
    private final   ArrayList<Car> CarList;
    private final   Semaphore FireSemaphore,  ListSemaphore ,DirectionSemaphore;
    private final   int MoveDuration = 3000 , RepositionDuration = 1000 , Height  ;
    private  final  AnchorPane Pane;



    CarThread(Car car  , Semaphore S_Fire , Semaphore listSemaphore , Semaphore directionSemaphore, ArrayList<Car> carList, int height, AnchorPane pane){
         this.The_Car = car;
         this.FireSemaphore = S_Fire;

         this.ListSemaphore = listSemaphore;
         this.DirectionSemaphore = directionSemaphore;
         this.CarList = carList;
         this.Height = height;
         this.Pane = pane;

    }

    @Override
    public void run() {
         reserveDirection();
         reserveFire();

         reserveList();
         reserveCar(The_Car);
        int index =  CarList.indexOf(The_Car);

        if(index >= 0){
            CarList.remove(index);
        }





        this.The_Car.move(MoveDuration,600);
        The_Car.getCarSemaphore().release();

        // make the waiting cars fall back in line

        new java.util.Timer().schedule(
                new java.util.TimerTask() {
                    @Override
                    public void run() {

                        FireSemaphore.release();

                    }
                },
                MoveDuration/3 + 100
        );


        repositionAllCars();
        ListSemaphore.release();

        new java.util.Timer().schedule(
                new java.util.TimerTask() {
                    @Override
                    public void run() {


                        DirectionSemaphore.release();
                    }
                },
                MoveDuration/3 + 100
        );

        new java.util.Timer().schedule(
                new java.util.TimerTask() {
                    @Override
                    public void run() {
                        Platform.runLater(()->{
                            Pane.getChildren().remove(The_Car.getCarModel());
                        });
                    }
                },
                MoveDuration
        );



    }

    private void reserveDirection() {
        try {
            this.DirectionSemaphore.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void reserveList() {
        try {

            this.ListSemaphore.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
            System.out.println("the car couldnt reserve the List");
        }
    }


    private void reserveCar(Car car) {
        try {
            car.getCarSemaphore().acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
            System.out.println("Car couldnt reserve itself");
        }
    }

    private void reserveFire() {
        try {
            FireSemaphore.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
            System.out.println("Car couldnt reserve the Fire");
        }
    }



    private void repositionAllCars(){
        CarList.forEach(car->{
          reserveCar(car);
          car.reposition(Height, RepositionDuration);
            // set action after some time;
            new java.util.Timer().schedule(
                    new java.util.TimerTask() {
                        @Override
                        public void run() {
                            car.getCarSemaphore().release();
                        }
                    },
                    RepositionDuration
            );
        });
    }
}
