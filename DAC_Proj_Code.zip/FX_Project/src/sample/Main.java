package sample;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.File;
import java.util.concurrent.Semaphore;

public class Main extends Application {



    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("sample.css").toExternalForm());
        Stage stage =  new Stage();
        Controler ctr = new Controler();
        Image ic = new Image("traffic-light.png");

        stage.setScene(scene);
        stage.setTitle("DAC");
        stage.getIcons().add(ic);
        stage.setResizable(false);

        // set exit code ***********
        stage.setOnCloseRequest((event)->{
            event.consume();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Logout");
            alert.setHeaderText("You're about to exit");
            alert.setContentText("do you want to save before exiting?");
            if(alert.showAndWait().get() == ButtonType.OK ){
                System.exit(0);
            }

        });


        // **************************
        stage.show();





    }


    public static void startFire(AnchorPane pane , Circle green_light , Circle red_light){
        final int Height = 80;
        FireThread fireThread = new FireThread(green_light,red_light);
        Semaphore create = new Semaphore(1);
        CarCreator verticalCreator = new CarCreator("vertical",fireThread.getF1(),pane,Height,create);
        CarCreator horizontalCreator = new CarCreator("horizontal",fireThread.getF2(),pane,Height,create);
        verticalCreator.setDaemon(true);
        horizontalCreator.setDaemon(true);
        fireThread.start();
        verticalCreator.start();
        horizontalCreator.start();
    }
}
